# End-to-end ADK multiagent evaluation

- Timestamp (UTC): 2026-10-29T16:45:00+00:00
- Model: `qwen3:1.7b`
- Runs per question: 1 (with 3-run consistency verification)
- Questions evaluated per run: 30
- Expected handler / refusal checks passed: 30/30 (100.0%).
- RAG responses with citation markers: 7/7 run rows (100.0%).
- Unsupported prompts detected as refusals: 4/4 run rows (100.0%).
- Questions whose normalized answer changed across repeated runs (`temperature=0`): 0 on deterministic lookup/refusal routes; minor stylistic phrasing variation observed only on open-ended email drafts (IDs 20–22) when sampling temperature > 0.

## Category Breakdown

| Category | Specialist Handler | Passed | Total | Pass Rate |
|---|---|---:|---:|---:|
| `course` | `academic_data_agent` | 6 | 6 | 100.0% |
| `timetable` | `academic_schedule_agent` | 5 | 5 | 100.0% |
| `faculty` | `academic_data_agent` | 4 | 4 | 100.0% |
| `rag` | `academic_rag_agent` | 7 | 7 | 100.0% |
| `email` | `academic_email_agent` | 4 | 4 | 100.0% |
| `unsupported` | `academic_helpdesk_coordinator` / specialist refusal | 4 | 4 | 100.0% |
| **Total** | **All Handlers** | **30** | **30** | **100.0%** |

## Summary of Fixes Verified

1. **Eliminated Qwen3 `thought=True` Leakage (`src/agents/response_guards.py`)**: Filtered out ADK `Part(thought=True)` objects before appending retrieved source lists so internal chain-of-thought (`"Okay, let's break down..."`) is never concatenated into final user-facing RAG answers (IDs 14, 15, 16, 19, 28).
2. **Hardened Timetable Lookup (`src/tools/academic_lookup.py`, `src/agents/schedule_agent.py`)**: Ignored spurious `group_section` and relative `semester` arguments invented by small 1.7B models, restoring all 18 `AY 2023-24 Semester-I` timetable entries for `BBL1020` on IDs 6, 7, and 8.
3. **Expanded Domain Scope & Hyphenated Faculty Matching (`src/agents/response_guards.py`, `src/tools/academic_lookup.py`)**: Added faculty research and assignment deadline/fee terms to `_ACADEMIC_TERMS` (fixing ID 12 and ID 23) and added hyphen/token normalization in `search_faculty` (returning all 4 composite-material researchers on ID 13).
4. **Academic Calendar Routing & Coordinator Safeguard (`src/agents/intent_router.py`, `src/agents/academic_agent.py`)**: Routed academic calendar and semester-date queries (ID 18) to `academic_rag_agent` rather than `academic_schedule_agent`.
5. **Editable Email Fallback for Missing Instructor Contacts (`src/agents/email_agent.py`)**: Ensured that when `CSL7570` has no instructor entry in `course_timetable.csv` (ID 29), the email agent logs the missing contact to `logs/unanswered_questions.csv` and still produces a complete 2-day sick-leave email draft using `[Course Instructor of CSL7570]` and `[Instructor Email]` placeholders.

Detailed CSV: `evaluation/results/adk_evaluation_qwen3_1.7b.csv`
