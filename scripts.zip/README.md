# Multi-Agent Academic Helpdesk — IIT Jodhpur

A local, laptop-friendly academic helpdesk that uses Google ADK, Ollama/LiteLLM specialist agents, ChromaDB RAG, and structured CSV tools. The ADK coordinator applies general intent classification to invoke the policy/RAG, schedule, data, or email specialist; specialist agents generate answers from retrieved documents or tool outputs. Unsupported questions are refused and logged for human review. Email output is a draft for the student to review; the application does not send email.

## Architecture

```text
Student request
      |
      v
ADK coordinator (`src/agents/academic_agent.py`)
      |-- course catalogue / faculty ----> `academic_data_agent`
      |                                      |-- course catalogue CSV
      |                                      |-- faculty contacts CSV
      |                                      |-- count and instructor-contact tools
      |-- timetable / slots -------------> `academic_schedule_agent`
      |                                      |-- timetable CSV
      |-- policy / calendar / rules ------> `academic_rag_agent`
      |                                      |-- Chroma retrieval
      |                                      |-- local Ollama answer with source labels
      |-- email drafting -----------------> `academic_email_agent`
                                             |-- optional instructor/contact lookup
                                             |-- editable email draft only

Unresolved request --> `logs/unanswered_questions.csv`
```

`src/agents/academic_agent.py` is an ADK `BaseAgent` orchestrator with deterministic intent routing to the four specialist agents. This avoids relying on the small local chat model to choose the correct route, while the specialists still use their tools and local language models to answer. `src/agents/router.py` is a separate direct tool-path baseline used for fast unit tests; its score is **not** an end-to-end ADK multiagent score. Use `scripts/run_adk_evaluation.py` to test the actual ADK orchestration and record which specialist agents appear in the event stream.

## Prerequisites

- Python 3.11 or 3.12 recommended.
- Ollama installed and running locally.
- Enough RAM for the selected local chat model and embedding model. The default is `qwen3:1.7b`; select another model available in Ollama using `ACADEMIC_HELPDESK_MODEL`.
- The collected source documents and structured CSVs. The code expects these structured files at:
  - `data/academic-helpdesk-data/academic-helpdesk/data/structured/course_catalog.csv`
  - `data/academic-helpdesk-data/academic-helpdesk/data/structured/course_timetable.csv`
  - `data/academic-helpdesk-data/academic-helpdesk/data/structured/faculty_contacts.csv`
- Academic PDFs under `data/academic-helpdesk-data/academic-helpdesk/data/documents/`.

The review archive used to prepare this README did not contain the `data/` folder or `vectorstore/`. Keep the original local copies when applying the code update. If starting from a clean clone, place the collected dataset in the paths above and build the index before using RAG.

## Installation on Windows PowerShell

From the project root (`F:\academic-helpdesk`):

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
ollama pull qwen3:1.7b
```

Check that Ollama is running and the model is available:

```powershell
ollama list
```

The model is configured with `ACADEMIC_HELPDESK_MODEL`. The default is `qwen3:1.7b`. For example, to compare against another model already supported by Ollama:

```powershell
ollama pull llama3.1:8b
$env:ACADEMIC_HELPDESK_MODEL = "llama3.1:8b"
```

Start a new PowerShell session or clear the variable to return to the default:

```powershell
Remove-Item Env:ACADEMIC_HELPDESK_MODEL -ErrorAction SilentlyContinue
```

See `.env.example` for additional environment variables. These variables are read directly from the environment; installing `python-dotenv` is not required.

## Prepare the document index

Run these steps only if the processed text or vector index does not exist, or if the source documents have changed. Index construction deletes and recreates the `academic_documents` collection, so do not run it just to test an answer.

```powershell
python src\rag\extract_documents.py
python src\rag\build_index.py
```

The expected persistent collection is `vectorstore/academic_helpdesk/academic_documents`. The indexing script reads the processed text under `data/processed/`.

## Run the multiagent application

Interactive ADK session:

```powershell
adk run src\agents
```

Structured JSON-line output (useful for debugging events and tool calls):

```powershell
adk run --jsonl src\agents
```

Example prompts to try:

- `What is the attendance requirement under the revised policy?`
- `What is the slot for the course Autonomous Systems?`
- `How many Open Elective credits do I need to earn to get a B.Tech degree?`
- `Write an email to the course instructor of CSL7570 saying I need sick leave for 2 days.`
- `What are the dining options on campus?`

Answers should cite retrieved document sources where applicable. If the sources do not support an academic answer, the helpdesk should refuse to guess. The timetable files may be historical; the assistant must preserve the academic year/semester shown in the data.

## Tests and evaluation

Run unit tests:

```powershell
python -m pytest tests -v
```

Run the fast deterministic router/tool-path baseline:

```powershell
python scripts\run_evaluation.py
```

That script writes `evaluation/results/evaluation_results.csv` and `reports/router_evaluation_report.md`. It tests routing/tool outputs, not the ADK coordinator handoff workflow.

Run the actual multiagent coordinator against all evaluation prompts:

```powershell
python scripts\run_adk_evaluation.py --runs 1
```

Run each prompt three times to inspect output variation:

```powershell
python scripts\run_adk_evaluation.py --runs 3
```

Run a small handoff smoke test before a full evaluation:

```powershell
python scripts\run_adk_evaluation.py --smoke
```

To compare models, run the script separately per model and retain both output files:

```powershell
python scripts\run_adk_evaluation.py --model qwen3:1.7b --runs 3 --output evaluation\results\adk_qwen3_1.7b.csv
python scripts\run_adk_evaluation.py --model llama3.1:8b --runs 3 --output evaluation\results\adk_llama3_1_8b.csv
```

Each ADK evaluation writes rows with observed event authors, expected handler (coordinator or specialist), whether the expected handler appeared, citation-marker presence, refusal-detection heuristics, and whether normalized answers changed across runs. Unsupported requests correctly refused by the coordinator are not counted as failed specialist handoffs. The generated Markdown report is stored under `reports/`.

**Important evaluation limitation:** citation-marker presence is not proof that a source supports a claim. Factual accuracy and semantic groundedness require a human reviewer to compare each response with the actual cited passage. The evaluation dataset is a project-specific set of prompts, not a standardized external benchmark.

## Unanswered-question log

The deterministic router logs not-found, insufficient-evidence, ambiguous-contact, and error outcomes to `logs/unanswered_questions.csv`. The ADK coordinator applies a domain-intent scope check: requests that do not match supported academic topics are refused before a specialist can guess and are logged for human review. This is a domain-scope check, not a list of question-specific answers. RAG tool evidence is passed through ADK state so the RAG response guard can keep the retrieved source list visible. The coordinator also logs specialist responses that clearly indicate missing evidence. The generated source list helps audit provenance; a human must still verify that each cited document supports the associated claims. The log records timestamp, question, route, status, and a short reason for human review. Review logs before sharing them because they may contain text the student submitted.

## Repository layout

```text
src/agents/       ADK coordinator, data/policy/schedule/email specialists; deterministic router
src/tools/        structured CSV search/count/contact functions
src/rag/          PDF extraction, Chroma indexing, retrieval and answer generation
src/utils/        unanswered-question logging
scripts/          router evaluation and end-to-end ADK evaluation
 tests/           unit tests
 evaluation/      30 evaluation prompts and generated result CSVs
 reports/         extraction and evaluation reports
```

## Known constraints to disclose in the final report

- Current timetable data is only as current as its underlying CSV records. The system must not present older rows as current.
- The email agent drafts only. It does not send mail.
- An instructor contact is returned only when timetable and faculty CSV matches are unambiguous; otherwise the draft uses placeholders.
- The current project extraction report records 91 PDFs processed successfully (37 circulars, 31 curriculum documents, 12 academic calendars and 11 regulations). This exceeds the brief's 20–30 document target; if the instructor expects exactly 20–30, curate a documented subset and rebuild the index from it.
- Do not report a single accuracy number from routing checks as overall answer accuracy. Report routing/handoff, citation, refusal, human-groundedness review, and repeated-run consistency separately.
