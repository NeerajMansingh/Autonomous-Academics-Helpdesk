
from pathlib import Path
import re
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[2]

# Use the collected dataset, not a guessed or separately created CSV.
DATA_DIR = (
    PROJECT_ROOT
    / "data"
    / "academic-helpdesk-data"
    / "academic-helpdesk"
    / "data"
    / "structured"
)


def _load_csv(filename: str) -> pd.DataFrame:
    """Load a CSV and normalize missing values."""
    path = DATA_DIR / filename

    if not path.is_file():
        raise FileNotFoundError(f"Required data file not found: {path}")

    df = pd.read_csv(path)
    return df.astype(object).where(pd.notna(df), "")

def search_courses(query: str, limit: int = 10) -> list[dict]:
    """Search course codes, titles, departments, and syllabus details."""
    df = _load_csv("course_catalog.csv")
    query = query.strip()

    if not query:
        return []

    columns = [
        "Course_Code",
        "Course_Title",
        "Department",
        "Program_Level",
        "Credits",
        "Category",
        "Focus_Area_Syllabus",
    ]

    mask = df[columns].astype(str).apply(
        lambda col: col.str.contains(query, case=False, regex=False)
    ).any(axis=1)

    return df.loc[mask, columns].head(max(1, limit)).to_dict("records")


def search_timetable(
    query: str,
    semester: str = "",
    group_section: str = "",
    limit: int = 20,
) -> list[dict]:
    """Search timetable records by course, instructor, day, or time slot."""
    df = _load_csv("course_timetable.csv")
    query = query.strip()
    semester = semester.strip()
    group_section = group_section.strip()
    if not query and not semester and not group_section:
        return []

    searchable_columns = [
        "Course_Code",
        "Course_Name",
        "Instructor",
        "Day",
        "Time_Slot",
    ]

    if query:
        mask = df[searchable_columns].astype(str).apply(
            lambda col: col.str.contains(query, case=False, regex=False)
        ).any(axis=1)
        df = df.loc[mask]

    if semester:
        df = df[
            df["Semester"].astype(str).str.contains(
                semester, case=False, regex=False
            )
        ]

    if group_section:
        df = df[
            df["Group_Section"].astype(str).str.contains(
                group_section, case=False, regex=False
            )
        ]

    return df.head(max(1, limit)).to_dict("records")


def search_faculty(query: str, limit: int = 10) -> list[dict]:
    """Search faculty names, departments, emails, and research areas."""
    df = _load_csv("faculty_contacts.csv")
    query = query.strip()

    if not query:
        return []

    columns = [
        "Name",
        "Designation",
        "Department",
        "Email",
        "Research_Areas",
        "Profile_URL",
    ]

    mask = df[columns].astype(str).apply(
        lambda col: col.str.contains(query, case=False, regex=False)
    ).any(axis=1)

    return df.loc[mask, columns].head(max(1, limit)).to_dict("records")


def count_courses(
    department: str = "",
    level: str = "",
    category: str = "",
    semester: str = "",
    require_timetable: bool = False,
) -> dict:
    """Count catalog courses using explicit filters and available records.

    When timetable evidence is requested, an exact semester is required.
    This prevents historical timetable data from being presented as the
    current semester's offering.
    """
    if require_timetable and not semester.strip():
        return {
            "status": "insufficient_evidence",
            "message": (
                "An exact academic year and semester are required to count "
                "courses offered in a specific term. The available data "
                "does not establish which timetable is current."
            ),
            "count": None,
            "courses": [],
        }

    df = _load_csv("course_catalog.csv")
    required = {"Course_Code", "Course_Title", "Department", "Category"}
    if not required.issubset(df.columns):
        return {
            "status": "insufficient_evidence",
            "message": "The course catalogue lacks fields needed for this count.",
            "count": None,
            "courses": [],
        }

    filtered = df.copy()
    if department.strip():
        filtered = filtered[
            filtered["Department"].astype(str).str.contains(
                department.strip(), case=False, regex=False, na=False
            )
        ]

    if level.strip():
        level_value = re.sub(r"\D", "", level)
        if not level_value:
            return {
                "status": "error",
                "message": "Level must be a numeric course level, such as 400.",
                "count": None,
                "courses": [],
            }
        level_digit = level_value[0]
        codes = filtered["Course_Code"].astype(str).str.extract(r"[A-Za-z]+(\d+)", expand=False)
        filtered = filtered.loc[codes.str.startswith(level_digit, na=False)]

    if category.strip():
        category_query = category.strip()
        filtered = filtered[
            filtered["Category"].astype(str).str.contains(
                category_query, case=False, regex=False, na=False
            )
        ]

    if require_timetable:
        timetable = _load_csv("course_timetable.csv")
        if not {"Course_Code", "Semester"}.issubset(timetable.columns):
            return {
                "status": "insufficient_evidence",
                "message": "The timetable lacks course-code or semester fields.",
                "count": None,
                "courses": [],
            }
        term_rows = timetable[
            timetable["Semester"].astype(str).str.contains(
                semester.strip(), case=False, regex=False, na=False
            )
        ]
        offered_codes = set(term_rows["Course_Code"].astype(str).str.strip().str.upper())
        filtered = filtered[
            filtered["Course_Code"].astype(str).str.strip().str.upper().isin(offered_codes)
        ]

    result_columns = [
        col for col in ("Course_Code", "Course_Title", "Department", "Program_Level", "Credits", "Category")
        if col in filtered.columns
    ]
    records = filtered[result_columns].to_dict("records")
    return {
        "status": "success",
        "count": len(records),
        "courses": records,
        "filters": {
            "department": department.strip(),
            "level": level.strip(),
            "category": category.strip(),
            "semester": semester.strip(),
            "require_timetable": require_timetable,
        },
        "source": "course_catalog.csv" + (" and course_timetable.csv" if require_timetable else ""),
        "note": (
            f"The count is limited to the exact semester filter '{semester.strip()}'."
            if require_timetable else
            "This is a catalogue count, not proof that every course is offered this semester."
        ),
    }


def _normalize_person_name(value: str) -> str:
    """Normalize titles and whitespace for conservative name matching."""
    text = re.sub(r"\s+", " ", str(value or "")).strip().casefold()
    text = re.sub(r"^(?:dr|prof|professor|doctor)\.?\s+", "", text)
    return text


def lookup_instructor_contact(course_code: str, semester: str = "") -> dict:
    """Find a course instructor in timetable data and match a published email.

    This function only returns names/emails present in the supplied CSVs.
    It reports ambiguity and keeps the semester evidence visible instead of
    selecting one instructor arbitrarily.
    """
    code = str(course_code or "").strip().upper()
    if not code:
        return {"status": "error", "message": "A course code is required."}

    timetable = _load_csv("course_timetable.csv")
    required = {"Course_Code", "Instructor"}
    if not required.issubset(timetable.columns):
        return {
            "status": "insufficient_evidence",
            "message": "The timetable lacks course-code or instructor fields.",
        }

    rows = timetable[
        timetable["Course_Code"].astype(str).str.strip().str.upper().eq(code)
    ].copy()
    if semester.strip() and "Semester" in rows.columns:
        rows = rows[
            rows["Semester"].astype(str).str.contains(
                semester.strip(), case=False, regex=False, na=False
            )
        ]

    if rows.empty:
        return {
            "status": "not_found",
            "course_code": code,
            "message": "No instructor record for this course was found in the timetable data.",
            "source": "course_timetable.csv",
        }

    if "Semester" in rows.columns:
        terms = sorted({str(v).strip() for v in rows["Semester"] if str(v).strip()})
    else:
        terms = []

    instructors = sorted(
        {str(v).strip() for v in rows["Instructor"] if str(v).strip()},
        key=str.casefold,
    )
    normalized_to_name = {}
    for name in instructors:
        normalized_to_name.setdefault(_normalize_person_name(name), name)
    normalized_to_name.pop("", None)

    if not normalized_to_name:
        return {
            "status": "not_found",
            "course_code": code,
            "semester_records": terms,
            "message": "The matching timetable records do not name an instructor.",
            "source": "course_timetable.csv",
        }

    if len(normalized_to_name) > 1:
        return {
            "status": "ambiguous",
            "course_code": code,
            "instructors": list(normalized_to_name.values()),
            "semester_records": terms,
            "message": (
                "Multiple instructors appear in the matching timetable records. "
                "Specify an exact semester/section before selecting a recipient."
            ),
            "source": "course_timetable.csv",
        }

    instructor = next(iter(normalized_to_name.values()))
    faculty = _load_csv("faculty_contacts.csv")
    required_faculty = {"Name", "Email"}
    if not required_faculty.issubset(faculty.columns):
        return {
            "status": "email_not_found",
            "course_code": code,
            "instructor": instructor,
            "semester_records": terms,
            "message": "An instructor was found, but the faculty contact file lacks name/email fields.",
            "source": "course_timetable.csv",
        }

    matched = faculty[
        faculty["Name"].astype(str).map(_normalize_person_name).eq(
            _normalize_person_name(instructor)
        )
    ]
    emails = sorted(
        {str(v).strip() for v in matched["Email"] if str(v).strip()},
        key=str.casefold,
    )

    common = {
        "course_code": code,
        "instructor": instructor,
        "semester_records": terms,
        "timetable_source": "course_timetable.csv",
    }
    if len(emails) == 1:
        return {
            "status": "success",
            **common,
            "email": emails[0],
            "faculty_source": "faculty_contacts.csv",
            "note": "Use the listed semester as the evidence scope; do not assume it is current.",
        }
    if len(emails) > 1:
        return {
            "status": "ambiguous",
            **common,
            "emails": emails,
            "message": "Multiple published email records match this instructor name.",
            "faculty_source": "faculty_contacts.csv",
        }
    return {
        "status": "email_not_found",
        **common,
        "message": "The instructor was found, but no exact faculty email match was available.",
        "faculty_source": "faculty_contacts.csv",
    }
