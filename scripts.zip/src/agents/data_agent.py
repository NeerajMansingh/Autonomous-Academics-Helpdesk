
import os

from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm

try:
    from tools.academic_lookup import (
        search_courses,
        search_faculty,
        count_courses,
        lookup_instructor_contact,
    )
except ModuleNotFoundError as exc:
    if not (exc.name == "tools" or str(exc.name).startswith("tools.")):
        raise

    from src.tools.academic_lookup import (
        search_courses,
        search_faculty,
        count_courses,
        lookup_instructor_contact,
    )


def lookup_courses(query: str) -> dict:
    """Search the course catalog by code, title, department, or topic."""
    results = search_courses(query, limit=5)

    if not results:
        return {
            "status": "not_found",
            "message": "No matching courses were found in the collected catalog.",
            "results": [],
        }

    return {
        "status": "success",
        "results": results,
        "note": "Details are from the collected course catalog.",
    }


def count_catalog_courses(
    department: str = "",
    level: str = "",
    category: str = "",
    semester: str = "",
    require_timetable: bool = False,
) -> dict:
    """Count courses using explicit department, level, category and term filters."""
    return count_courses(
        department=department,
        level=level,
        category=category,
        semester=semester,
        require_timetable=require_timetable,
    )


def find_course_instructor_contact(course_code: str, semester: str = "") -> dict:
    """Find an instructor and published email for a course, if unambiguous."""
    return lookup_instructor_contact(course_code=course_code, semester=semester)


def lookup_faculty(query: str) -> dict:
    """Search faculty by name, department, designation, or research area."""
    results = search_faculty(query, limit=5)

    if not results:
        return {
            "status": "not_found",
            "message": "No matching faculty records were found.",
            "results": [],
        }

    return {
        "status": "success",
        "results": results,
        "note": "Use only returned details; never invent missing information.",
    }


root_agent = Agent(
    name="academic_data_agent",
    mode="single_turn",
    model=LiteLlm(model=f"ollama_chat/{os.getenv('ACADEMIC_HELPDESK_MODEL', 'qwen3:1.7b').strip()}", api_base=os.getenv("ACADEMIC_HELPDESK_OLLAMA_API_BASE", "http://localhost:11434")),
    description=(
        "Specialist for course catalog and faculty records."
    ),
    instruction="""
You are the Academic Data Specialist for IIT Jodhpur.

TOOL REQUIREMENTS:
- Course questions: call lookup_courses before answering.
- Faculty questions: call lookup_faculty before answering.
- For numerical course-catalog questions, call count_catalog_courses. Pass explicit filters you can identify from the question. Do not claim a catalog count proves a course is offered this semester. For term-specific counts, require an exact academic year/semester; if unavailable, report insufficient evidence.
- For instructor contact requests, call find_course_instructor_contact. Use only returned names/emails and preserve ambiguity or historical-semester information.
- Never answer a lookup question from memory instead of using its tool.

ACCURACY:
- Base factual answers only on actual tool results.
- Never invent course details, schedules, names, email addresses, or URLs.
- If a result has status not_found, report that no matching record was found.
- If a field is missing, say it was not provided.
- Treat records from AY 2023-24 or earlier as historical.
- Never describe historical timetable records as current.
- Do not infer that a record does not exist just because a search failed.

RESPONSE:
- Answer only what the user asked.
- Keep answers concise and factual.
- Do not display planning text or internal reasoning.
""",
    tools=[
        lookup_courses,
        lookup_faculty,
        count_catalog_courses,
        find_course_instructor_contact,
    ],
)
