"""LLM-directed ADK coordinator for the Academic Helpdesk."""

from __future__ import annotations

import os
import re

from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm
from google.genai import types

try:
    from agents.data_agent import root_agent as data_agent
    from agents.email_agent import root_agent as email_agent
    from agents.rag_agent import root_agent as rag_agent
    from agents.schedule_agent import root_agent as schedule_agent
    from agents.response_guards import is_academic_helpdesk_query, refusal_text, preserve_rag_citations
except ModuleNotFoundError as exc:
    if not (
        exc.name == "agents"
        or str(exc.name).startswith("agents.")
    ):
        raise

    from src.agents.data_agent import root_agent as data_agent
    from src.agents.email_agent import root_agent as email_agent
    from src.agents.rag_agent import root_agent as rag_agent
    from src.agents.schedule_agent import root_agent as schedule_agent
    from src.agents.response_guards import is_academic_helpdesk_query, refusal_text, preserve_rag_citations


MODEL_NAME = os.getenv("ACADEMIC_HELPDESK_MODEL", "qwen3:1.7b").strip()
PRIVATE_PHONE_PATTERN = re.compile(
    r"\b(?:private|personal)\s+(?:phone|mobile)\s+number\b",
    re.IGNORECASE,
)

UNRESOLVED_PATTERN = re.compile(
    r"could not determine this reliably|insufficient evidence|"
    r"not enough evidence|no matching (?:course|faculty|timetable|record|records)|"
    r"not found in the collected|could not find|"
    r"email address (?:was )?not found|unable to verify|"
    r"cannot verify from the available|local model request failed|"
    r"document retrieval tool encountered an error",
    re.IGNORECASE,
)


def _question_text(context) -> str:
    """Extract the initial user message from ADK context."""
    content = getattr(context, "user_content", None)
    parts = getattr(content, "parts", None) or []

    return " ".join(
        str(getattr(part, "text", "") or "").strip()
        for part in parts
        if getattr(part, "text", None)
    ).strip()


def _log_unanswered(
    question: str,
    *,
    route: str,
    status: str,
    reason: str,
) -> None:
    """Record unresolved or refused requests without breaking the response."""
    try:
        try:
            from src.utils.unanswered_logger import log_unanswered_question
        except ModuleNotFoundError:
            from utils.unanswered_logger import log_unanswered_question

        log_unanswered_question(
            question,
            route=route,
            status=status,
            reason=(reason or "The request could not be resolved.")[:500],
        )
    except (OSError, ImportError):
        # Logging failure must not prevent a user-facing response.
        pass


def _content(text: str) -> types.Content:
    """Create a standard ADK text response."""
    return types.Content(
        role="model",
        parts=[types.Part.from_text(text=text)],
    )


def _guard_request(callback_context):
    """Apply safety and scope checks before the coordinator calls the LLM."""
    question = _question_text(callback_context)

    if PRIVATE_PHONE_PATTERN.search(question):
        message = (
            "I cannot disclose private faculty contact information. Please use "
            "an officially published institutional contact channel."
        )
        _log_unanswered(
            question,
            route="academic_helpdesk_coordinator",
            status="refused_private_contact",
            reason=message,
        )
        return _content(message)

    if not is_academic_helpdesk_query(question):
        message = refusal_text()
        _log_unanswered(
            question,
            route="academic_helpdesk_coordinator",
            status="out_of_scope",
            reason=message,
        )
        return _content(message)

    return None


def _log_unresolved_model_response(callback_context, llm_response):
    """Log an unresolved final coordinator response, not intermediate tool calls."""
    parts = getattr(getattr(llm_response, "content", None), "parts", None) or []

    # Do not interpret an agent transfer or tool call as the final answer.
    if any(getattr(part, "function_call", None) for part in parts):
        return None

    answer = "\n".join(
        str(getattr(part, "text", "") or "").strip()
        for part in parts
        if getattr(part, "text", None)
    ).strip()

    if not answer or not UNRESOLVED_PATTERN.search(answer):
        return None

    question = _question_text(callback_context)
    not_found = re.search(
        r"no matching|not found in the collected|could not find|"
        r"email address (?:was )?not found",
        answer,
        re.IGNORECASE,
    )

    _log_unanswered(
        question,
        route="llm_coordinator",
        status="not_found" if not_found else "insufficient_evidence",
        reason=answer,
    )
    return None




def _coordinator_after_model(callback_context, llm_response):
    """Log unresolved answers and preserve retrieved RAG source references."""
    _log_unresolved_model_response(callback_context, llm_response)
    return preserve_rag_citations(callback_context, llm_response)

root_agent = Agent(
    name="academic_helpdesk_coordinator",
    model=LiteLlm(model=f"ollama_chat/{MODEL_NAME}", api_base=os.getenv("ACADEMIC_HELPDESK_OLLAMA_API_BASE", "http://localhost:11434")),
    description=(
        "LLM coordinator for the IIT Jodhpur Academic Helpdesk. "
        "Selects the appropriate academic specialist based on the user's request."
    ),
    instruction="""
You are the coordinating agent for the IIT Jodhpur Academic Helpdesk.

DELEGATION:
- The specialist agents are callable tools named academic_data_agent,
  academic_schedule_agent, academic_rag_agent, and academic_email_agent.
- For an in-scope request, CALL the appropriate specialist tool. Do not merely
  announce, describe, or narrate a planned tool call.
- A specialist tool returns its result to you. Use that result to answer the
  user. Call more than one specialist when the request needs distinct evidence.
- You decide which specialist agent or agents should handle each in-scope request.
- Do not use a hard-coded route table or classify requests by fixed keywords.
- Before answering a factual academic question, delegate to the appropriate
  specialist. Do not invent factual answers from model memory.
- Use academic_data_agent for course catalog searches, course counts,
  faculty records, and published instructor contacts.
- Use academic_schedule_agent for timetable rows, class slots, days,
  semesters, and sections.
- Use academic_rag_agent for academic regulations, circulars, attendance,
  examinations, curriculum, policies, and academic information that requires
  document retrieval.
- Use academic_email_agent for drafting academic emails. It can look up a
  published instructor contact when the request requires one.
- For a request involving multiple distinct needs, you may consult more than
  one specialist and combine their verified findings.
- Use each specialist's returned evidence; never claim that a tool succeeded
  unless its result supports that claim.

ACCURACY:
- Do not invent dates, course offerings, timetable slots, faculty contacts,
  policy rules, citations, or email addresses.
- Preserve historical dates and semesters. Never present historical timetable
  rows as current.
- If evidence is missing, ambiguous, or insufficient, say so clearly.
- Preserve source labels and citations returned by the document specialist.
- If the request is outside this helpdesk's academic scope, refuse it rather
  than guessing.
- Never disclose private faculty contact information.
- An email request means draft only; never claim that an email was sent.

RESPONSE:
- Give a concise answer to the user's actual request.
- Do not expose internal reasoning, routing instructions, or planning text.
""",
    sub_agents=[
        data_agent,
        schedule_agent,
        rag_agent,
        email_agent,
    ],
    before_agent_callback=_guard_request,
    after_model_callback=_coordinator_after_model,
)
