"""Dedicated timetable/schedule specialist for the Academic Helpdesk."""

import os

from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm

try:
    from tools.academic_lookup import search_timetable
except ModuleNotFoundError as exc:
    if not (exc.name == "tools" or str(exc.name).startswith("tools.")):
        raise
    from src.tools.academic_lookup import search_timetable


def lookup_schedule(
    query: str,
    semester: str = "",
    group_section: str = "",
) -> dict:
    """Return schedule rows only from the collected timetable CSV."""
    if not query.strip() and not semester.strip() and not group_section.strip():
        return {
            "status": "insufficient_evidence",
            "message": "Please specify a course code/title or an exact semester/section before looking up a timetable.",
            "results": [],
        }
    results = search_timetable(
        query,
        semester=semester,
        group_section=group_section,
        limit=10,
    )
    if not results:
        return {
            "status": "not_found",
            "message": "No matching timetable records were found in the collected data.",
            "results": [],
        }
    return {
        "status": "success",
        "results": results,
        "source": "course_timetable.csv",
        "warning": (
            "Preserve the Semester value exactly as returned. Do not describe a "
            "historical timetable as current or infer a future timetable."
        ),
    }


root_agent = Agent(
    name="academic_schedule_agent",
    mode="single_turn",
    model=LiteLlm(model=f"ollama_chat/{os.getenv('ACADEMIC_HELPDESK_MODEL', 'qwen3:1.7b').strip()}", api_base=os.getenv("ACADEMIC_HELPDESK_OLLAMA_API_BASE", "http://localhost:11434")),
    description="Specialist for course time slots, timetables, days, semesters and sections.",
    instruction="""
You are the Academic Schedule Specialist for IIT Jodhpur.

- Call lookup_schedule before answering any timetable, slot, class time, day, or section question.
- Use only rows returned by the tool. Do not create a schedule from memory.
- Preserve academic year, semester, time-slot, instructor, and group/section values as returned.
- If the tool returns not_found, say no matching row was found in the collected data.
- Do not describe AY 2023-24 or other historical timetable rows as current.
- If the question concerns a future term for which no exact timetable is available, refuse to guess and explain the evidence gap.
- Include the timetable source and term in the final answer where provided.
""",
    tools=[lookup_schedule],
)
