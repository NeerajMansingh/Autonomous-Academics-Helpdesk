import os


from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm
from google.adk.tools import ToolContext

try:
    from rag.answer_question import answer_academic_documents
    from agents.response_guards import RAG_RESULT_STATE_KEY, preserve_rag_citations
except ModuleNotFoundError as exc:
    if not (exc.name == "rag" or str(exc.name).startswith("rag.") or exc.name == "agents" or str(exc.name).startswith("agents.")):
        raise

    from src.rag.answer_question import answer_academic_documents
    from src.agents.response_guards import RAG_RESULT_STATE_KEY, preserve_rag_citations


def search_academic_documents(question: str, tool_context: ToolContext) -> dict:
    """Search academic documents and retain source evidence for final citations."""
    result = answer_academic_documents(question)
    # Share the tool's evidence with the coordinator's response guard so source
    # references are not silently lost during agent-to-agent summarization.
    tool_context.state[RAG_RESULT_STATE_KEY] = {
        "status": result.get("status"),
        "sources": [
            {
                "source": item.get("source") or item.get("document_name")
            }
            for item in result.get("sources", [])
            if isinstance(item, dict)
            and (item.get("source") or item.get("document_name"))
        ],
    }
    return result


root_agent = Agent(
    name="academic_rag_agent",
    mode="single_turn",
    model=LiteLlm(model=f"ollama_chat/{os.getenv('ACADEMIC_HELPDESK_MODEL', 'qwen3:1.7b').strip()}", api_base=os.getenv("ACADEMIC_HELPDESK_OLLAMA_API_BASE", "http://localhost:11434")),
    description=(
        "Specialist for academic regulations, circulars, attendance, "
        "examinations, curriculum, and academic policies."
    ),
    instruction="""
You are the Academic Document Specialist for IIT Jodhpur.

- For document-based questions, call search_academic_documents.
- Base answers on the returned answer and evidence.
- Preserve source dates and do not present old rules as current without
  supporting evidence.
- If the tool reports insufficient_evidence, do not guess.
- Do not invent facts or citations.
- Keep answers concise and include source information when available.
- Preserve [Source N] labels from the tool result verbatim. If you summarize,
  retain the labels beside the claims they support; do not strip them.
""",
    tools=[search_academic_documents],
    after_model_callback=preserve_rag_citations,
)
