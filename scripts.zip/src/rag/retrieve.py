from pathlib import Path

import chromadb
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = Path(__file__).resolve().parents[2]
VECTORSTORE_DIR = PROJECT_ROOT / "vectorstore" / "academic_helpdesk"
COLLECTION_NAME = "academic_documents"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def retrieve(query: str, top_k: int = 5) -> None:
    model = SentenceTransformer(EMBEDDING_MODEL)

    client = chromadb.PersistentClient(path=str(VECTORSTORE_DIR))
    collection = client.get_collection(COLLECTION_NAME)

    query_embedding = model.encode(
        [query],
        normalize_embeddings=True,
    ).tolist()

    results = collection.query(
        query_embeddings=query_embedding,
        n_results=top_k,
    )

    for i, (document, metadata, distance) in enumerate(
        zip(
            results["documents"][0],
            results["metadatas"][0],
            results["distances"][0],
        ),
        start=1,
    ):
        print(f"\n--- Result {i} ---")
        print(f"Source: {metadata['source']}")
        print(f"Category: {metadata['category']}")
        print(f"Distance: {distance:.4f}")
        print(document[:700])


if __name__ == "__main__":
    question = input("Enter an academic question: ").strip()

    if question:
        retrieve(question)