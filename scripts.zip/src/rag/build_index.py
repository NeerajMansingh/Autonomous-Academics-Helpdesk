
from pathlib import Path
import re

import chromadb
from sentence_transformers import SentenceTransformer


PROJECT_ROOT = Path(__file__).resolve().parents[2]
PROCESSED_DIR = PROJECT_ROOT / "data" / "processed"
VECTORSTORE_DIR = PROJECT_ROOT / "vectorstore" / "academic_helpdesk"
COLLECTION_NAME = "academic_documents"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L6-v2"

CHUNK_SIZE = 1200
CHUNK_OVERLAP = 200


def split_text(text: str) -> list[str]:
    """Split text into overlapping character chunks."""
    text = text.strip()
    if not text:
        return []

    chunks = []
    start = 0

    while start < len(text):
        end = min(start + CHUNK_SIZE, len(text))
        chunk = text[start:end].strip()

        if chunk:
            chunks.append(chunk)

        if end == len(text):
            break

        start = end - CHUNK_OVERLAP

    return chunks


def main() -> None:
    if not PROCESSED_DIR.exists():
        raise FileNotFoundError(
            f"Processed text directory not found: {PROCESSED_DIR}"
        )

    text_files = sorted(PROCESSED_DIR.rglob("*.txt"))
    if not text_files:
        raise RuntimeError(f"No extracted text files found in {PROCESSED_DIR}")

    print(f"Text files found: {len(text_files)}")
    print("Loading embedding model...")
    model = SentenceTransformer(EMBEDDING_MODEL)

    client = chromadb.PersistentClient(path=str(VECTORSTORE_DIR))

    # Rebuild this collection so rerunning the script does not add duplicates.
    try:
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass

    collection = client.create_collection(
        name=COLLECTION_NAME,
        metadata={"hnsw:space": "cosine"},
    )

    all_ids = []
    all_documents = []
    all_metadatas = []

    for file_path in text_files:
        text = file_path.read_text(encoding="utf-8", errors="replace")
        chunks = split_text(text)

        source_name = file_path.name
        category = file_path.parent.name

        for index, chunk in enumerate(chunks):
            chunk_id = f"{file_path.relative_to(PROCESSED_DIR).as_posix()}::{index}"

            all_ids.append(chunk_id)
            all_documents.append(chunk)
            all_metadatas.append({
                "source": source_name,
                "source_path": str(file_path),
                "category": category,
                "chunk_index": index,
            })

    if not all_documents:
        raise RuntimeError("No non-empty text chunks were created.")

    batch_size = 64

    for start in range(0, len(all_documents), batch_size):
        end = start + batch_size
        docs_batch = all_documents[start:end]

        embeddings = model.encode(
            docs_batch,
            normalize_embeddings=True,
            show_progress_bar=False,
        ).tolist()

        collection.add(
            ids=all_ids[start:end],
            documents=docs_batch,
            metadatas=all_metadatas[start:end],
            embeddings=embeddings,
        )

        print(f"Indexed {min(end, len(all_documents))}/{len(all_documents)} chunks")

    print("\nIndex build complete.")
    print(f"Chunks indexed: {collection.count()}")
    print(f"Vector database: {VECTORSTORE_DIR}")


if __name__ == "__main__":
    main()
