from src.agents.response_guards import (
    append_retrieved_source_list,
    is_academic_helpdesk_query,
    refusal_text,
)


def test_scope_guard_accepts_representative_academic_topics():
    prompts = [
        "Find course BBL1020 and tell me its title and credits",
        "What is the slot for the course Autonomous Systems?",
        "What is the weightage and duration of the Major examination?",
        "Write an email to my course instructor asking for sick leave",
        "How many Open Elective credits do I need for a B.Tech. degree?",
    ]
    assert all(is_academic_helpdesk_query(prompt) for prompt in prompts)


def test_scope_guard_rejects_out_of_scope_examples():
    prompts = [
        "What are the available dining options on the campus?",
        "What is the best way to reach campus from Jodhpur city center?",
    ]
    assert all(not is_academic_helpdesk_query(prompt) for prompt in prompts)
    assert "I don't know" in refusal_text()


def test_source_list_is_added_when_rag_answer_omits_citations():
    result = {
        "status": "success",
        "sources": [
            {"source": "Academic-Regulations.pdf (Page 3)"},
            {"source": "Examination-Rules.pdf (Page 2)"},
        ],
    }
    answer = append_retrieved_source_list("The examination has a stated weightage and duration.", result)
    assert "[Source 1] Academic-Regulations.pdf (Page 3)" in answer
    assert "[Source 2] Examination-Rules.pdf (Page 2)" in answer


def test_source_list_is_added_to_citations_but_not_refusals():
    result = {"status": "success", "sources": [{"source": "Rules.pdf"}]}
    refusal = "I could not determine this reliably from the available sources."
    already_cited = "The rule is described in the document [Source 1]."
    assert append_retrieved_source_list(refusal, result) == refusal
    cited_with_source_list = append_retrieved_source_list(already_cited, result)
    assert "[Source 1]" in cited_with_source_list
    assert "Rules.pdf" in cited_with_source_list
