import pandas as pd

from src.tools import academic_lookup


def fixture_data():
    catalog = pd.DataFrame([
        {"Course_Code": "HSS4010", "Course_Title": "Elective A", "Department": "Humanities", "Program_Level": "UG", "Credits": "3", "Category": "Elective"},
        {"Course_Code": "HSS4020", "Course_Title": "Elective B", "Department": "Humanities", "Program_Level": "UG", "Credits": "3", "Category": "Elective"},
        {"Course_Code": "CSL4010", "Course_Title": "Systems", "Department": "Computer Science", "Program_Level": "UG", "Credits": "4", "Category": "Core"},
    ])
    timetable = pd.DataFrame([
        {"Course_Code": "HSS4010", "Course_Name": "Elective A", "Instructor": "Dr Anurag Sharma", "Day": "Mon", "Time_Slot": "A", "Semester": "AY 2023-24 Semester-I", "Group_Section": "A"},
        {"Course_Code": "HSS4020", "Course_Name": "Elective B", "Instructor": "Dr Anurag Sharma", "Day": "Tue", "Time_Slot": "B", "Semester": "AY 2023-24 Semester-I", "Group_Section": "A"},
    ])
    faculty = pd.DataFrame([
        {"Name": "Anurag Sharma", "Email": "anurag@example.edu", "Department": "Humanities", "Designation": "Professor", "Research_Areas": "Policy", "Profile_URL": ""},
    ])
    return {"course_catalog.csv": catalog, "course_timetable.csv": timetable, "faculty_contacts.csv": faculty}


def test_count_requires_exact_term_for_offering_count(monkeypatch):
    data = fixture_data()
    monkeypatch.setattr(academic_lookup, "_load_csv", lambda filename: data[filename])

    result = academic_lookup.count_courses(
        department="Humanities", level="400", category="elective", require_timetable=True
    )

    assert result["status"] == "insufficient_evidence"
    assert result["count"] is None


def test_count_filters_catalog_and_explicit_semester(monkeypatch):
    data = fixture_data()
    monkeypatch.setattr(academic_lookup, "_load_csv", lambda filename: data[filename])

    result = academic_lookup.count_courses(
        department="Humanities",
        level="400",
        category="elective",
        semester="AY 2023-24 Semester-I",
        require_timetable=True,
    )

    assert result["status"] == "success"
    assert result["count"] == 2
    assert {row["Course_Code"] for row in result["courses"]} == {"HSS4010", "HSS4020"}


def test_instructor_contact_only_returns_exact_published_email(monkeypatch):
    data = fixture_data()
    monkeypatch.setattr(academic_lookup, "_load_csv", lambda filename: data[filename])

    result = academic_lookup.lookup_instructor_contact("HSS4010")

    assert result["status"] == "success"
    assert result["instructor"] == "Dr Anurag Sharma"
    assert result["email"] == "anurag@example.edu"
    assert result["semester_records"] == ["AY 2023-24 Semester-I"]
